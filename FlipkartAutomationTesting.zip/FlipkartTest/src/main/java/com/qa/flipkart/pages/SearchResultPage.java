package com.qa.flipkart.pages;

public class SearchResultPage {

}
